import {v4} from 'uuid'

export const uuid = () => v4()