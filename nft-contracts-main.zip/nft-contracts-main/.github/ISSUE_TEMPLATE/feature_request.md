---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

**Summary**
Please describe your idea in one paragraph.

**Motivation**
Why do you think this problem is important? 

**Describe the solution you'd like**
Please explain how you propose to solve this issue
